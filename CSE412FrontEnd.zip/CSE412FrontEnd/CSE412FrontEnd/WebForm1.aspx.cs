﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using System.Xml;

namespace CSE412FrontEnd
{
	public partial class WebForm1 : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			int min = Convert.ToInt32(Text1.Value);
			int max = Convert.ToInt32(Text2.Value);
			var client = new WebClient();
			client.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome / 58.0.3029.110 Safari / 537.36");

			var response = client.DownloadString("http://localhost:3998/Service1.svc/GetData?min=1&max=5&title=startup&tag=startup");

			var release = XElement.Parse(response);
			var series1 = new System.Web.UI.DataVisualization.Charting.Series
			{
				Name = "Series1",
				Color = System.Drawing.Color.Green,
				ChartType = SeriesChartType.Bar
			};
			this.Chart2.Series.Add(series1);
			this.Chart2.ChartAreas["ChartArea1"].AxisX.Interval = 1;
			this.Chart2.ChartAreas["ChartArea1"].AxisY.Interval = 250;


			List<string> qr = new List<string>();
			foreach (string p in release.Elements())
			{
				qr.Add(p);
			}

			for (int i = 0; i < qr.Count(); i = i + 2)
			{
				if (i + 1 < qr.Count())
					series1.Points.AddXY(qr.ElementAt(i), qr.ElementAt(i + 1));
			}

			//TODO call avg service
			var client1 = new WebClient();
			client1.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome / 58.0.3029.110 Safari / 537.36");

			var response1 = client1.DownloadString("http://localhost:3998/Service1.svc/GetRating?min=1&max=5&title=startup&tag=startup");

			var release1 = XElement.Parse(response1);
			var series11 = new System.Web.UI.DataVisualization.Charting.Series
			{
				Name = "Series11",
				Color = System.Drawing.Color.Green,
				ChartType = SeriesChartType.Bar
			};
			this.Chart3.Series.Add(series11);
			this.Chart3.ChartAreas["ChartArea1"].AxisX.Interval = 1;
			this.Chart3.ChartAreas["ChartArea1"].AxisY.Interval = 1;


			List<string> qr1 = new List<string>();
			foreach (string p1 in release1.Elements())
			{
				qr1.Add(p1);
			}

			for (int i1 = 0; i1 < qr1.Count(); i1 = i1 + 2)
			{
				if (i1 + 1 < qr1.Count())
					series11.Points.AddXY(qr1.ElementAt(i1), qr1.ElementAt(i1 + 1));
			}

		}

		protected void Button1_Click(object sender, EventArgs e)
		{
			int min = Convert.ToInt32(Text1.Value);
			int max = Convert.ToInt32(Text2.Value);
			string title = TextBox1.Text;
			string tag = TextBox2.Text;

			var client = new WebClient();
			client.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome / 58.0.3029.110 Safari / 537.36");
	
			var response = client.DownloadString("http://localhost:3998/Service1.svc/GetData?min="+min+"&max="+max+"&title="+TextBox1.Text+"&tag="+TextBox2.Text);

			var release = XElement.Parse(response);
			Chart2.Series.Clear();

			var series1 = new System.Web.UI.DataVisualization.Charting.Series
			{
				Name = "Series1",
				Color = System.Drawing.Color.Green,
				ChartType = SeriesChartType.Bar
			};
			this.Chart2.Series.Add(series1);
			this.Chart2.ChartAreas["ChartArea1"].AxisX.Interval = 1;
			this.Chart2.ChartAreas["ChartArea1"].AxisY.Interval = 100;


			List<string> qr = new List<string>();
			foreach(string p in release.Elements())
			{
				qr.Add(p);
			}

			for (int i = 0; i < qr.Count(); i=i+2)
			{
				if (i + 1 < qr.Count())
				series1.Points.AddXY(qr.ElementAt(i), qr.ElementAt(i+1));
			}

			//TODO call avg service
			var client1 = new WebClient();
			client1.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome / 58.0.3029.110 Safari / 537.36");

			var response1 = client1.DownloadString("http://localhost:3998/Service1.svc/GetRating?min=1&max=5&title=startup&tag=startup");

			var release1 = XElement.Parse(response1);
			Chart3.Series.Clear();

			var series11 = new System.Web.UI.DataVisualization.Charting.Series
			{
				Name = "Series11",
				Color = System.Drawing.Color.Green,
				ChartType = SeriesChartType.Bar
			};
			this.Chart3.Series.Add(series11);
			this.Chart3.ChartAreas["ChartArea1"].AxisX.Interval = 1;
			this.Chart3.ChartAreas["ChartArea1"].AxisY.Interval = 1;


			List<string> qr1 = new List<string>();
			foreach (string p1 in release1.Elements())
			{
				qr1.Add(p1);
			}

			for (int i1 = 0; i1 < qr1.Count(); i1 = i1 + 2)
			{
				if (i1 + 1 < qr1.Count())
					series11.Points.AddXY(qr1.ElementAt(i1), qr1.ElementAt(i1 + 1));
			}

		}

		protected void Chart1_Load(object sender, EventArgs e)
		{

		}

	}
}